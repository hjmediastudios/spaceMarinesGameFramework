#pragma once
#include "Main.hpp"
#include <vector>

class GeoFile
{
public:
	GeoFile() {}
	GeoFile(BinaryFile& file);
	~GeoFile();
	unsigned short getNumJoints() const;
	unsigned int getNumIndices() const;
	unsigned int getNumVertices() const;

	GeoFile concatenateWith(const GeoFile &other) const;
	void write(BinaryFile &file);
private:
	bool verifyGeoFile(BinaryFile &file);
	int versionNumber;

	int numJoints;
	std::vector<char> jointData;

	int numVertexStreams;
	int numVertices;

	std::vector<float> vertex_positionData;
	std::vector<short> vertex_normalData;
	std::vector<short> vertex_tangentData;
	std::vector<short> vertex_bitangentData;
	std::vector<unsigned char> vertex_jointIndicesData;
	std::vector<unsigned char> vertex_jointWeightsData;
	std::vector<float> vertex_uvsSet0Data;
	std::vector<float> vertex_uvsSet1Data;

	int numTriangleIndices;
	std::vector<int> triangleIndices;

	int numMorphTargets;

	void readVertexStream(BinaryFile &file);
	void checkForConcatenatability(const GeoFile &other) const;

	template <typename T>
	void printVector(const std::vector<T> &vec) const;

	template <typename T>
	std::vector<T> appendVector(const std::vector<T> &vecA, const std::vector<T> &b) const;
};
