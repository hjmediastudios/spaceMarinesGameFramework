#include "GeoFile.hpp"

GeoFile::GeoFile(BinaryFile &file)
{
	cout << "Creating geo file from file \"" << file.getFilename() << "\"\n";
	if (!verifyGeoFile(file)) throw std::exception();
	versionNumber = file.read<int>();
	cout << "\tVersion number " << versionNumber << endl;
	if (versionNumber != 5) throw std::exception();

	numJoints = file.read<int>();
	cout << "\tNumber of joints: " << numJoints << endl;
	//Read joints
	file.readIntoVector(jointData, numJoints * sizeof(float) * 16);

	numVertexStreams = file.read<int>();
	cout << "\t" << numVertexStreams << " vertex streams.\n";

	//Read vertices
	numVertices = file.read<int>();
	cout << "\t" << numVertices << " vertices.\n";
	for (unsigned short i = 0; i < numVertexStreams; i++)
	{
		readVertexStream(file);
	}

	//Triangle index stream
	numTriangleIndices = file.read<int>();
	cout << "\t" << numTriangleIndices << " triangle indices\n";
	file.readIntoVector(triangleIndices, numTriangleIndices);

	numMorphTargets = file.read<int>();
	cout << "\t" << numMorphTargets << " morph targets.\n";
	if (numMorphTargets > 0)
		std::cerr << "Morph targets are unsupported so far.\n";

}

GeoFile::~GeoFile()
{

}

unsigned short GeoFile::getNumJoints() const
{
	return numJoints;
}

unsigned int GeoFile::getNumIndices() const
{
	return numTriangleIndices;
}

unsigned int GeoFile::getNumVertices() const
{
	return numVertices;
}

bool GeoFile::verifyGeoFile(BinaryFile &file)
{
	std::string h3dString = "";
	for (short i = 0; i < 4; i++)
	{
		h3dString += file.read<char>();
	}
	if (h3dString != "H3DG")
		return false;
	else
		return true;
}

void GeoFile::readVertexStream(BinaryFile &file)
{
	int type = file.read<int>();
	int streamElementSize = file.read<int>();
	switch(type)
	{
	case 0:
		//Vertex positions
		cout << "\t\tVertex positions[3f]:  " << streamElementSize << " * " << numVertices << endl;
		file.readIntoVector(vertex_positionData, 3 * numVertices);
		break;
	case 1:
		//Vertex normals
		cout << "\t\tVertex normals[3H]:    " << streamElementSize << " * " << numVertices << endl;
		file.readIntoVector(vertex_normalData, 3 * numVertices);
		break;
	case 2:
		//Vertex tangents
		cout << "\t\tVertex tangents[3H]:   " << streamElementSize << " * " << numVertices << endl;
		file.readIntoVector(vertex_tangentData, 3 * numVertices);
		break;
	case 3:
		//Vertex bitangents
		cout << "\t\tVertex bitangents[3H]: " << streamElementSize << " * " << numVertices << endl;
		file.readIntoVector(vertex_bitangentData, 3 * numVertices);
		break;
	case 4:
		//Vertex joint indices
		cout << "\t\tVertex joint ind.[4C]: " << streamElementSize << " * " << numVertices << endl;
		file.readIntoVector(vertex_jointIndicesData, 4 * numVertices);
		break;
	case 5:
		//Vertex joint weights
		cout << "\t\tVertex joint wgt.[4C]: " << streamElementSize << " * " << numVertices << endl;
		file.readIntoVector(vertex_jointWeightsData, 4 * numVertices);
		break;
	case 6:
		//Vertex UVs set 0
		cout << "\t\tVertex UVs set 0[2f]:  " << streamElementSize << " * " << numVertices << endl;
		file.readIntoVector(vertex_uvsSet0Data, 2 * numVertices);
		break;
	case 7:
		//Vertex UVs set 1
		cout << "\t\tVertex UVs set 1[2f]:  " << streamElementSize << " * " << numVertices << endl;
		file.readIntoVector(vertex_uvsSet1Data, 2 * numVertices);
		break;
	default:
		std::cerr << "GeoFile contains unsupported vertex stream element \"" << type << "\"\n";
		throw std::exception();
		break;
	}
}

void GeoFile::checkForConcatenatability(const GeoFile &other) const
{
	if (versionNumber != other.versionNumber)
	{
		cerr << "Version numbers of two files don't match\n";
		throw std::exception();
	}
	if (numJoints != other.numJoints)
	{
		cerr << "Joint count of two files don't match\n";
		throw std::exception();
	}
	if (numVertexStreams != other.numVertexStreams)
	{
		cerr << "Vertex stream count of two files don't match\n";
		throw std::exception();
	}
}

GeoFile GeoFile::concatenateWith(const GeoFile &other) const
{
	checkForConcatenatability(other);
	GeoFile ret;

	ret.versionNumber = versionNumber;

	//Copy joint data over
	ret.numJoints = numJoints;
	ret.jointData = jointData;

	//Copy vertex data over
	ret.numVertexStreams = numVertexStreams;
	ret.numVertices = numVertices + other.numVertices;

	ret.vertex_positionData = appendVector(vertex_positionData, other.vertex_positionData);
	ret.vertex_normalData = appendVector(vertex_normalData, other.vertex_normalData);
	ret.vertex_tangentData = appendVector(vertex_tangentData, other.vertex_tangentData);
	ret.vertex_bitangentData = appendVector(vertex_bitangentData, other.vertex_bitangentData);
	ret.vertex_jointIndicesData = appendVector(vertex_jointIndicesData, other.vertex_jointIndicesData);
	ret.vertex_jointWeightsData = appendVector(vertex_jointWeightsData, other.vertex_jointWeightsData);
	ret.vertex_uvsSet0Data = appendVector(vertex_uvsSet0Data, other.vertex_uvsSet0Data);
	ret.vertex_uvsSet1Data = appendVector(vertex_uvsSet1Data, other.vertex_uvsSet1Data);

	//Copy triangle index data over
	ret.numTriangleIndices = numTriangleIndices + other.numTriangleIndices;

	printVector(triangleIndices);
	printVector(other.triangleIndices);
	ret.triangleIndices = appendVector(triangleIndices, other.triangleIndices);
	for (int i = numTriangleIndices; i < ret.triangleIndices.size(); i++)
	{
		ret.triangleIndices[i] += numVertices;
	}
	printVector(ret.triangleIndices);


	ret.numMorphTargets = numMorphTargets;
	return ret;
}

void GeoFile::write(BinaryFile &file)
{
	//Writing is OK. It must be a problem with concatenation.

	//Write header
	file.write('H');file.write('3');file.write('D');file.write('G');
	file.write<int>(5);

	//Write joint data
	file.write<int>(numJoints);
	file.writeFromVector(jointData);

	//Write vertex data
	file.write<int>(numVertexStreams);
	file.write<int>(numVertices);

	//Write positions
	file.write<int>(0); file.write<int>(12);
	file.writeFromVector(vertex_positionData);
	//Write normals
	file.write<int>(1); file.write<int>(6);
	file.writeFromVector(vertex_normalData);
	//Write tangents
	file.write<int>(2); file.write<int>(6);
	file.writeFromVector(vertex_tangentData);
	//Write bitangents
	file.write<int>(3); file.write<int>(6);
	file.writeFromVector(vertex_bitangentData);

	if (numJoints > 1)
	{
		//Write joint indices
		file.write<int>(4); file.write<int>(4);
		file.writeFromVector(vertex_jointIndicesData);
		//Write joint weights
		file.write<int>(5); file.write<int>(4);
		file.writeFromVector(vertex_jointWeightsData);
	}

	//Write UV set 0
	file.write<int>(6); file.write<int>(8);
	file.writeFromVector(vertex_uvsSet0Data);
	//Write UV set 1
	file.write<int>(7); file.write<int>(8);
	file.writeFromVector(vertex_uvsSet1Data);

	//Write triangle indices
	file.write<int>(numTriangleIndices);
	file.writeFromVector(triangleIndices);

	//Write morph targets
	file.write(0);

}

template <typename T>
std::vector<T> GeoFile::appendVector(const vector<T> &vecA, const vector<T> &vecB) const
{
	std::vector<T> ret;
	size_t firstLength = vecA.size();
	ret.reserve(firstLength + vecB.size());
	for (size_t i=0; i < vecA.size(); i++)
	{
		ret.push_back(vecA[i]);
	}
	for (size_t i=0; i < vecB.size(); i++)
	{
		ret.push_back(vecB[i]);
	}

	return ret;
}

template<typename T>
void GeoFile::printVector(const std::vector<T> &vec) const
{
	for (size_t i = 0; i < vec.size(); i++)
	{
		std::cout << vec[i] << " ";
	}
	std::cout << endl;
}
