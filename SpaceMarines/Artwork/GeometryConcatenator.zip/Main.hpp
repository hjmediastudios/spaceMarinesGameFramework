#pragma once

#include <iostream>
#include <tinyxml2.h>
#include "BinaryFile.hpp"
#include "GeoFile.hpp"
#include <sys/stat.h>

using namespace std;
using namespace tinyxml2;
