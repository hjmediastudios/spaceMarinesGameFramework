#pragma once
#include <fstream>
#include <string>
#include <vector>

/**
 * An enumeration of all binary-file opening types, chiefly those for input (Read) and output (Write).
 */
namespace BinaryFileOpenTypes
{
	enum List
	{
		Read = 0,
		Write
	};
};

/**
 * A class representing a file containing binary data
 */
class BinaryFile
{
public:
	/**
	 * Constructs a Binary File at the given path with the specified opening type
	 * @param path the filepath to the file
	 * @param openType the type of opening, for input (Read) or output (Write)
	 */
	BinaryFile(const char* path, BinaryFileOpenTypes::List openType)
	{
		filename = std::string(path);
		file = new std::fstream(path, std::ios::binary | (openType == BinaryFileOpenTypes::Read ? std::ios::in : std::ios::out));
		if (!file || file->eof()) throw std::exception();
		file->seekg(0, std::ios::end);
		size = file->tellg();
		file->seekg(0, std::ios::beg);
	}

	/**
	 * Closes the binary file and deletes it.
	 */
	~BinaryFile()
	{
		close();
		delete file;
	}

	void close()
	{
		if (file->is_open()) file->close();
	}

	/**
	 * Reads a value of the specified type at the current cursor position and returns it
	 * @return The value of the specified type read from the current cursor position
	 */
	template<typename T>
	T read()
	{
		T item;
		file->read(reinterpret_cast<char*>(&item), sizeof(T));
		return item;
	}

	/**
	 * Checks if the file contains content past the cursor
	 * @return false if the end of the file has been reached, true otherwise
	 */
	bool hasMore()
	{
		return (!file->eof() && file->tellg() < size);
	}

	/**
	 * Skips over data for a specified distance
	 * @param size the size of the data to skip over
	 */
	void skip(unsigned long size)
	{
		file->seekg(size, std::ios::cur);
	}

	/**
	 * Returns the current cursor position in the file
	 * @return the cursor position
	 */
	size_t getCursorPosition()
	{
		return file->tellg();
	}

	/**
	 * Sets the file's cursor position to the given point in the file, without checking
	 * for errors
	 */
	void setCursorPosition(size_t pos)
	{
		file->seekg(pos, std::ios::beg);
	}

	/**
	 * Writes an item into the file. Note that checking if the file is writeable is not
	 * performed.
	 */
	template<typename T>
	void write(const T &item)
	{
		file->write(reinterpret_cast<const char*>(&item), sizeof(T));
	}

	/**
	 * Returns the filename of the current file
	 * @return the filename
	 */
	const char* getFilename()
	{
		return filename.c_str();
	}

	/**
	 * Reads a consecutive batch of items of type T into the provided vector
	 * @param vec the vector that values will be added into
	 * @param numElements the number of elements of the given type to read
	 */
	template<typename T>
	void readIntoVector(std::vector<T> &vec, size_t numElements)
	{
		if (numElements < 1)
		{
			std::cerr << "Wrong!\n";
			return;
		}
		vec = std::vector<T>(numElements);
		for (size_t i = 0; i < numElements; i++)
		{
			vec[i] = read<T>();
		}
	}

	template<typename T>
	void writeFromVector(const std::vector<T> &vec)
	{
		if (vec.size() < 1)
		{
			std::cerr << "Wrong!\n";
			return;
		}
		std::cout << "vec length: " << vec.size() << "\n";
		for (size_t i = 0; i < vec.size(); i++)
		{
			write(vec[i]);
			//std::cout << "\t\t" << vec[i] << "\n";
		}
	}

private:
	std::fstream* file;
	size_t size;
	std::string filename;
};
