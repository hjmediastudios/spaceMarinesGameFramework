#include "Main.hpp"

std::string extractAppPath(const char* fullPath)
{
	const string s(fullPath);
	if (s.find("/") != std::string::npos)
		return s.substr(0, s.rfind("/")) + "/";
	else if (s.find("\\") != std::string::npos)
		return s.substr(0, s.rfind("\\")) + "\\";
	else
		return "";
}

std::string extractFilename(const char* fullPath)
{
	const string s(fullPath);
	if (s.find("/") != std::string::npos)
		return s.substr(s.rfind("/") + 1, s.length());
	else if (s.find("\\") != std::string::npos)
		return s.substr(s.rfind("\\") + 1, s.length());
	else
		return "";
}

std::string extractNameBeforeExtension(const char* name)
{
	const string s(name);
	if (s.find(".") != std::string::npos)
		return s.substr(0, s.find("."));
	else
		return "";
}

void copyFiles(const char* fileSrc, const char* fileDest)
{
	ifstream src(fileSrc, ios::binary);
	ofstream dest(fileDest, ios::binary);

    istreambuf_iterator<char> begin_source(src);
    istreambuf_iterator<char> end_source;
    ostreambuf_iterator<char> begin_dest(dest);
    copy(begin_source, end_source, begin_dest);

    src.close();
    dest.close();
}

int main(int numArgs, char* args[])
{
	if (numArgs < 4)
	{
		cerr << "Invalid number of arguments\n";
		return -1;
	}

	string file3Name = extractNameBeforeExtension(extractFilename(args[3]).c_str());
	cout << "Output name: " << file3Name.c_str() << endl;

	string path = extractAppPath(args[0]);
	string file1Path = path + "../" + args[1];
	string file2Path = path + "../" + args[2];
	string file3Path = path + "../" + args[3];

	cout << "File 1: " << file1Path << endl;
	cout << "File 2: " << file2Path << endl;
	cout << "File 3: " << file3Path << endl << endl;

	copyFiles(file1Path.c_str(), file3Path.c_str());

	XMLDocument model1file;
	XMLDocument model2file;
	XMLDocument model3file;

	if (model1file.LoadFile(file1Path.c_str()) != XML_NO_ERROR)
	{
		cerr << "Problem loading the first file.\n";
		return -1;
	}
	if (model2file.LoadFile(file2Path.c_str()) != XML_NO_ERROR)
	{
		cerr << "Problem loading the second file.\n";
		return -1;
	}

	mkdir(extractAppPath(file3Path.c_str()).c_str(), 0755);
	if (model3file.LoadFile(file3Path.c_str()) != XML_NO_ERROR)
	{
		cerr << "Problem loading the output file.\n";
		return -1;
	}

	XMLElement* model1 = model1file.RootElement();
	XMLElement* model2 = model2file.RootElement();
	XMLElement* model3 = model3file.RootElement();

	string model1geoPath = path + "../assets/" + model1->Attribute("geometry");
	string model2geoPath = path + "../assets/" + model2->Attribute("geometry");
	string model3geoPath = path + "../assets/models/" + file3Name + "/" + file3Name + ".geo";

	cout << "Model 1 path: " << model1geoPath << endl;
	cout << "Model 2 path: " << model2geoPath << endl;
	cout << "Model 3 path: " << model3geoPath << endl;

	//Find number of vertices in model 1
	XMLElement* cursor = nullptr;
	cursor = model1->LastChildElement("Mesh");
	if (!cursor->NoChildren())
		cursor = cursor->LastChildElement("Mesh");


	XMLElement* masterMesh = cursor->Parent()->ToElement();
	unsigned int batchEnd = cursor->IntAttribute("batchStart") + cursor->IntAttribute("batchCount");
	unsigned int vertEnd = cursor->IntAttribute("vertREnd");

	cout << "Master mesh name: " << masterMesh->Attribute("name") << endl;
	cout << "1st batch end: " << batchEnd << endl;
	cout << "1st vertex end: " << vertEnd << endl;

	model3->SetAttribute("name", file3Name.c_str());
	model3->SetAttribute("geometry", ("models/" + file3Name + "/" + file3Name + ".geo").c_str());

	unsigned short lodLevel = model1->LastChildElement("Mesh")->IntAttribute("lodLevel");

	XMLElement* newMesh = model3file.NewElement("Mesh");
	model3->InsertEndChild(newMesh);
	model3->FirstChildElement("Mesh")->SetAttribute("lodLevel", lodLevel);
	for (const XMLAttribute* att = model2->FirstChildElement("Mesh")->FirstAttribute(); att != nullptr; att = att->Next())
	{
		newMesh->SetAttribute(att->Name(), att->Value());
	}
	newMesh->SetAttribute("name", (string(masterMesh->Attribute("name"))).c_str());

	newMesh->SetAttribute("lodLevel", lodLevel + 1);
	newMesh->SetAttribute("batchStart", newMesh->UnsignedAttribute("batchStart") + batchEnd);
	newMesh->SetAttribute("vertRStart", newMesh->UnsignedAttribute("vertRStart") + vertEnd + 1);
	newMesh->SetAttribute("vertREnd", newMesh->UnsignedAttribute("vertREnd") + vertEnd + 1);

	//Loop through submeshes
	for (XMLElement* cursor = model2->FirstChildElement("Mesh")->FirstChildElement("Mesh"); cursor != nullptr; cursor = cursor->NextSiblingElement("Mesh"))
	{
		cout << "Cursor\n";
		XMLElement* newMeshPrime = model3file.NewElement("Mesh");
		newMesh->InsertEndChild(newMeshPrime);
		for (const XMLAttribute* att = cursor->FirstAttribute(); att != nullptr; att = att->Next())
		{
			newMeshPrime->SetAttribute(att->Name(), att->Value());
		}
		newMeshPrime->SetAttribute("name", (string(newMeshPrime->Attribute("name"))).c_str());
		newMeshPrime->SetAttribute("batchStart", newMeshPrime->UnsignedAttribute("batchStart") + batchEnd);
		newMeshPrime->SetAttribute("vertRStart", newMeshPrime->UnsignedAttribute("vertRStart") + vertEnd);
		newMeshPrime->SetAttribute("vertREnd", newMeshPrime->UnsignedAttribute("vertREnd") + vertEnd);
	}

	model3->SetAttribute("lodDist1", 25);
	//StartHere output to model 3
	model3file.SaveFile(file3Path.c_str());

	//We're done with the model files; now let's concatenate the geometry files
	BinaryFile geoFile1 = BinaryFile(model1geoPath.c_str(), BinaryFileOpenTypes::Read);
	BinaryFile geoFile2 = BinaryFile(model2geoPath.c_str(), BinaryFileOpenTypes::Read);
	BinaryFile geoFile3 = BinaryFile(model3geoPath.c_str(), BinaryFileOpenTypes::Write);
	BinaryFile geoFile4 = BinaryFile((model1geoPath + ".1").c_str(), BinaryFileOpenTypes::Write);

	GeoFile gFile1(geoFile1);
	GeoFile gFile2(geoFile2);

	GeoFile gFile3 = gFile1.concatenateWith(gFile2);
	cout << "Result:\n\t" << gFile3.getNumVertices() << " vertices\n";
	cout << "\t" << gFile3.getNumIndices() << " indices\n";
	gFile3.write(geoFile3);
	geoFile3.close();

	gFile1.write(geoFile4);
	geoFile4.close();

	BinaryFile geoFile3b = BinaryFile(model3geoPath.c_str(), BinaryFileOpenTypes::Read);
	GeoFile gFile3b(geoFile3b);

	return 0;
}

